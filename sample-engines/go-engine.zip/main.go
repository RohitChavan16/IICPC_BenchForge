package main

import (
	"encoding/json"
	"net/http"
	"sync"
)

type Order struct {
	OrderID string  `json:"order_id"`
	Symbol  string  `json:"symbol"`
	Side    string  `json:"side"`
	Price   float64 `json:"price"`
	Quantity int    `json:"quantity"`
}

type Trade struct {
	MakerOrderID string  `json:"maker_order_id"`
	Price        float64 `json:"price"`
	Quantity     int     `json:"quantity"`
}

type Response struct {
	Status           string  `json:"status"`
	ExecutedQuantity int     `json:"executed_quantity"`
	Trades           []Trade `json:"trades"`
}

var mu sync.Mutex
var orderBook []Order

func orderHandler(w http.ResponseWriter, r *http.Request) {
	var o Order
	if err := json.NewDecoder(r.Body).Decode(&o); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	var trades []Trade
	executedQuantity := 0
	remainingQuantity := o.Quantity

	mu.Lock()
	defer mu.Unlock()

	var newBook []Order
	for _, resting := range orderBook {
		if remainingQuantity == 0 {
			newBook = append(newBook, resting)
			continue
		}

		if o.Symbol == resting.Symbol && o.Side != resting.Side {
			canMatch := false
			if o.Side == "buy" && o.Price >= resting.Price {
				canMatch = true
			}
			if o.Side == "sell" && o.Price <= resting.Price {
				canMatch = true
			}

			if canMatch {
				matchQty := remainingQuantity
				if resting.Quantity < matchQty {
					matchQty = resting.Quantity
				}

				matchPrice := resting.Price // execution price is resting order price
				trades = append(trades, Trade{
					MakerOrderID: resting.OrderID,
					Price:        matchPrice,
					Quantity:     matchQty,
				})
				executedQuantity += matchQty
				remainingQuantity -= matchQty

				if resting.Quantity > matchQty {
					resting.Quantity -= matchQty
					newBook = append(newBook, resting)
				}
			} else {
				newBook = append(newBook, resting)
			}
		} else {
			newBook = append(newBook, resting)
		}
	}

	if remainingQuantity > 0 {
		o.Quantity = remainingQuantity
		newBook = append(newBook, o)
	}
	orderBook = newBook

	status := "resting"
	if remainingQuantity == 0 {
		status = "filled"
	} else if executedQuantity > 0 {
		status = "partial"
	}

	if trades == nil {
		trades = []Trade{} // Ensure it marshals to [] instead of null
	}

	resp := Response{
		Status:           status,
		ExecutedQuantity: executedQuantity,
		Trades:           trades,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp)
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	w.Write([]byte(`{"status":"ok"}`))
}

func main() {
	http.HandleFunc("/health", healthHandler)
	http.HandleFunc("/order", orderHandler)

	http.ListenAndServe(":8080", nil)
}